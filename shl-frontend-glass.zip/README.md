# SHL Frontend — Glassmorphism UI

This is a modern React + Tailwind frontend scaffold (glassmorphism theme) for your SHL GenAI assessment.

Quick start:
1. Extract the zip.
2. Create a `.env` in the project root:
   REACT_APP_API_URL=https://your-backend-base-url
3. Run:
   npm install
   npm start

The frontend calls POST ${REACT_APP_API_URL}/recommend with JSON body { "query": "..." }.
