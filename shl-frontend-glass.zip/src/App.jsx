import React, { useState } from 'react';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import ResultsList from './components/ResultsList';
import Spinner from './components/Spinner';
import { getRecommendations } from './api/recommend';

export default function App(){
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSearch(q){
    try{
      setError('');
      setLoading(true);
      setItems([]);
      const data = await getRecommendations(q);
      const recs = data.recommended_assessments || data.recommendations || data;
      setItems(Array.isArray(recs) ? recs : []);
    }catch(err){
      console.error(err);
      setError(err?.response?.data?.message || err.message || 'Failed to fetch');
    }finally{
      setLoading(false);
    }
  }

  return (
    <div>
      <Header />
      <SearchBar onSearch={handleSearch} loading={loading} />
      <main className="container">
        {error && <div className="p-3 bg-red-50 text-red-700 rounded my-4">{error}</div>}
        {loading ? <Spinner /> : <ResultsList items={items} />}
      </main>
      <footer className="container py-8 text-sm muted">
        Built for SHL GenAI assessment — connect REACT_APP_API_URL to your backend.
      </footer>
    </div>
  );
}
