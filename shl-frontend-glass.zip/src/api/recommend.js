import axios from 'axios';
const BASE = process.env.REACT_APP_API_URL || 'https://YOUR_BACKEND_URL';
export async function getRecommendations(query) {
  const url = `${BASE.replace(/\/+$/, '')}/recommend`;
  const resp = await axios.post(url, { query });
  return resp.data;
}
