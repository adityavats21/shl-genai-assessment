import React from 'react';
import logo from '../assets/logo.svg';

export default function Header(){
  return (
    <header className="brand-grad text-white py-8">
      <div className="container flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src={logo} alt="logo" className="h-12 w-12 rounded-lg shadow-sm"/>
          <div>
            <h1 className="text-2xl font-semibold">SHL Assessment Recommender</h1>
            <p className="text-sm muted">AI-powered recommendations for hiring assessments</p>
          </div>
        </div>
        <nav className="space-x-4 muted hidden md:block">
          <a href="#how" className="hover:underline">How it works</a>
          <a href="#results" className="hover:underline">Results</a>
          <a href="#about" className="hover:underline">About</a>
        </nav>
      </div>
    </header>
  );
}
