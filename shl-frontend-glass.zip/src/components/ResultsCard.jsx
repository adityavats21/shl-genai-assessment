import React from 'react';

export default function ResultsCard({ item }){
  return (
    <div className="glass p-4 rounded-xl">
      <div className="flex items-start gap-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-white">{item.name}</h3>
          <p className="muted mt-2">{item.description || '—'}</p>
          <div className="mt-3 flex items-center gap-3">
            <span className="text-sm bg-white/8 px-2 py-1 rounded">{item.duration ? item.duration + ' min' : '—'}</span>
            {item.test_type?.map((t,i)=>(
              <span key={i} className="text-sm px-2 py-1 bg-white/6 rounded">{t}</span>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-2">
          {item.url && <a className="px-3 py-2 bg-white text-blue-700 rounded font-medium" href={item.url} target="_blank" rel="noreferrer">Open</a>}
        </div>
      </div>
    </div>
  );
}
