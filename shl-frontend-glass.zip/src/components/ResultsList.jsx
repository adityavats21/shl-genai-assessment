import React from 'react';
import ResultsCard from './ResultsCard';

export default function ResultsList({ items = [] }){
  if(!items.length) return <div className="container py-10 text-center muted">No recommendations yet — submit a query.</div>;
  return (
    <div className="container grid md:grid-cols-2 gap-4 py-6">
      {items.map((it, idx)=> <ResultsCard key={idx} item={it} />)}
    </div>
  );
}
