import React, { useState } from 'react';

export default function SearchBar({ onSearch, loading }){
  const [q, setQ] = useState('');
  return (
    <div className="container -mt-12">
      <form onSubmit={(e)=>{e.preventDefault(); if(q.trim()) onSearch(q.trim());}} className="glass p-5 rounded-xl shadow">
        <div className="flex flex-col md:flex-row gap-4">
          <textarea
            rows="4"
            value={q}
            onChange={(e)=>setQ(e.target.value)}
            placeholder="Paste Job Description, job URL, or type what you need — e.g. 'Mid-level Python developer with SQL'"
            className="flex-1 p-3 rounded-md bg-transparent border border-white/10 text-white placeholder-white/60"
            style={{minHeight:120}}
          />
          <div className="flex items-end gap-3">
            <button className="px-5 py-3 rounded-lg bg-white text-blue-700 font-semibold shadow hover:scale-[1.02] transition">
              {loading ? 'Searching...' : 'Get Recommendations'}
            </button>
            <button type="button" onClick={()=>{ setQ('Mid-level Python engineer with SQL and data skills'); }} className="text-sm muted underline">
              Try sample
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
