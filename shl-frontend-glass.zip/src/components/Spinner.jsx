import React from 'react';
export default function Spinner(){ return <div className="p-6 text-center">Loading…</div>; }
